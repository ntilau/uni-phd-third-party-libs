These files are need to compile METIS on Windows.
