MATLAB interface for CXSparse.  See Contents.m for details.
