% CXSparse MATLAB demos.
%
%   cs_demo  - run all CXSparse demos.
%   cs_demo1 - MATLAB version of the CSparse/Demo/cs_demo1.c program.
%   cs_demo2 - MATLAB version of the CSparse/Demo/cs_demo2.c program.
%   cs_demo3 - MATLAB version of the CSparse/Demo/cs_demo3.c program.

% Example:
%   help cs_demo

%   Copyright 2006-2007, Timothy A. Davis
